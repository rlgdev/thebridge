#!/usr/bin/env python3
"""v0 COBOL structure extractor (regex starter, fixed-format).
Usage: python scripts/extract_structure.py <src-dir> [<copybook-dir>]"""
import re, sys, pathlib

SRC = pathlib.Path(sys.argv[1]); CPY = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else None
OUT = pathlib.Path("docs/cobol-context")
(OUT / "programs").mkdir(parents=True, exist_ok=True)
(OUT / "copybooks").mkdir(exist_ok=True)

def code(text):  # strip fixed-format comment lines + sequence/ident columns
    return "\n".join(ln[6:72] for ln in text.splitlines()
                     if len(ln) > 6 and ln[6] not in "*/").upper()

def find(root, exts):
    return sorted(p for p in root.rglob("*") if p.suffix.lower() in exts)

rows = []
for f in find(SRC, {".cbl", ".cob"}):
    t = code(f.read_text(errors="ignore"))
    m = re.search(r"PROGRAM-ID\.\s+([A-Z0-9-]+)", t)
    pid = m.group(1) if m else f.stem.upper()
    calls = sorted(set(re.findall(r"CALL\s+['\"]([A-Z0-9-]+)['\"]", t)))
    dyn   = sorted(set(re.findall(r"CALL\s+(?!['\"])([A-Z][A-Z0-9-]*)", t)))
    copys = sorted(set(re.findall(r"\bCOPY\s+([A-Z0-9-]+)", t)))
    perfs = sorted({p for p in re.findall(r"(?<!-)\bPERFORM +([0-9A-Z][A-Z0-9-]*)", t)
                    if not p.isdigit()}
                   - {"UNTIL", "VARYING", "TIMES", "WITH", "TEST"})
    files = sorted(set(re.findall(r"\bSELECT\s+([A-Z0-9-]+)\s+ASSIGN", t)))
    flags = [k for k, p in [("DB2", r"EXEC\s+SQL"), ("CICS", r"EXEC\s+CICS")] if re.search(p, t)]
    (OUT / "programs" / f"{pid}.md").write_text(f"""# PROGRAM-ID: {pid}
> Source: `{f}` · Extractor: v0 regex — facts below are extracted, verify edge cases

## Purpose (GENERATED-SUMMARY — verify against source)
_TODO_

## Facts (extracted)
- Static CALLs: {', '.join(calls) or 'none'}
- Dynamic CALLs via: {', '.join(dyn) or 'none'}
- Copybooks: {', '.join(copys) or 'none'}
- PERFORM targets: {', '.join(perfs) or 'none'}
- Files (SELECT): {', '.join(files) or 'none'}
- Embedded: {', '.join(flags) or 'none'}

## Structure notes (GENERATED-SUMMARY — verify)
_TODO_
""")
    rows.append(f"| {pid} | {', '.join(calls + dyn) or '-'} | {', '.join(copys) or '-'} | {', '.join(flags) or '-'} | `{f}` |")

(OUT / "_index.md").write_text(
    "# COBOL program inventory (v0)\n\n| Program | Calls | Copybooks | Embedded | Source |\n|---|---|---|---|---|\n"
    + "\n".join(rows) + "\n")

if CPY:
    for c in find(CPY, {".cpy"}):
        t = code(c.read_text(errors="ignore"))
        frows = []
        for m in re.finditer(r"^\s*(\d{2})\s+([A-Z0-9-]+)([^.]*)\.", t, re.M | re.S):
            lvl, name, rest = m.group(1), m.group(2), m.group(3)
            pm = re.search(r"PIC\s+([^\s.]+)", rest)
            notes = ", ".join(re.findall(r"REDEFINES\s+[A-Z0-9-]+|OCCURS\s+\d+|COMP-3|COMP\b", rest))
            frows.append(f"| {lvl} | {name} | {pm.group(1) if pm else '-'} | {notes or '-'} |")
        (OUT / "copybooks" / f"{c.stem.upper()}.md").write_text(
            f"# COPYBOOK: {c.stem.upper()}\n> Source: `{c}` · v0 field list (no offsets — add cb2xml for offsets)\n\n"
            "| Level | Field | PIC | Notes |\n|---|---|---|---|\n" + "\n".join(frows) + "\n")
