#!/usr/bin/env python3
"""Fill the Purpose / Structure notes sections of generated program pages
via Claude Code headless mode. Run from the repo root after extract_structure.py."""
import json, pathlib, shutil, subprocess, sys

CLAUDE = shutil.which("claude")
if not CLAUDE:
    sys.exit("Claude Code CLI ('claude') not found on PATH - install and authenticate it first.")
PAGES = sorted(pathlib.Path("docs/cobol-context/programs").glob("*.md"))
if not PAGES:
    sys.exit("No pages found - run scripts/extract_structure.py first.")

for p in PAGES:
    prompt = (
        f"Fill the '## Purpose' and '## Structure notes' sections of {p} in place. "
        "Ground every claim in the Facts section of that file and in the source file it "
        "references. Use only paragraph, program and field names that exist there. "
        "Do not change the Facts section."
    )
    r = subprocess.run(
        [CLAUDE, "-p", prompt, "--allowedTools", "Read,Grep,Edit",
         "--max-turns", "10", "--output-format", "json"],
        capture_output=True, text=True)
    try:
        out = json.loads(r.stdout)
        print(f"{p.name}: turns={out.get('num_turns')} cost_usd={out.get('total_cost_usd')}")
    except (json.JSONDecodeError, ValueError):
        print(f"{p.name}: unexpected output\n{r.stdout or r.stderr}")
