# Scoring rubric

Score the saved `spec.md` / `plan.md` / `tasks.md` of each run against the
sealed ground truth. One row per (CR, variant) in `runsheet.csv`.

| Metric | How to score |
|---|---|
| Current-behavior accuracy | spec's description of existing behavior vs. reality: 0 wrong / 1 partial / 2 correct |
| Affected-asset recall | % of programs+copybooks from the sealed truth that appear in spec/plan |
| Hallucinated identifiers | count of nonexistent program/paragraph/field names across all three files |
| Clarification burden | # of questions or `[NEEDS CLARIFICATION]` markers that the code itself could have answered |
| Task executability | % of tasks referencing real files/paragraphs a developer could start without re-research |

Pass bar (adjust before running):
- with-context beats baseline on >= 3 of 5 metrics on every CR
- affected-asset recall >= 80%, hallucinated identifiers <= 2 per run
- no metric materially worse than baseline
