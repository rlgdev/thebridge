# CR-XX: <short title>

## Description (this text is given to the agent via /speckit.specify)

<Realistic change request touching the pilot programs, e.g.:
"Extend ACCT-STATUS from PIC X to PIC XX end-to-end: input file,
processing logic, DB2 column, report layout.">

## Sealed ground truth — move OUTSIDE both worktrees before running
Keep this section in e.g. `~/cobol-eval/CR-XX.truth.md` until scoring.

- Affected programs:
- Affected copybooks / fields:
- Affected paragraphs:
- Files / DB2 tables / CICS transactions:
