## COBOL context

`docs/cobol-context/` holds extracted structure for the COBOL codebase.
For any COBOL task: read `_index.md`, then `programs/<PROG>.md`, then
`copybooks/<COPY>.md` for layouts — before opening raw source. Grep this
folder first for impact questions; identifiers appear verbatim.
The "Facts" sections are extracted and authoritative for navigation;
GENERATED-SUMMARY sections must be verified in source. Never invent
program, paragraph, or field names.
